this is a software that include reminder and alarm
please make sure all the code in the same folder when running the program

library :
pip install tkcalendar
pip install pygame
